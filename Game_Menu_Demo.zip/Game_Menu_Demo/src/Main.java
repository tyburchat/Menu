/**
 * Program Name: Main.java
 * Purpose: Make a menu with game options that a user can input and interact with
 * Coder: Ty Burchat | 1246765
 * Date: Jan 19, 2024
 */

import java.util.*;

public class Main
{

	public static void main(String[] args)// this acts as the main menu
	{
		// Creating a Scanner and String value for menu
		String difficulty = "Nuh-uh";
		Scanner input = new Scanner(System.in);
		String choice;

		//Output Menu to user.
		while(true) {
			System.out.println("1. Guessing Game\n2. Battle Ship\n3. Exit\nType the number or the word of the game you would like to play!");
			choice = input.nextLine().toLowerCase();// Take user's input and puts it to lower case.
			
			//If checks if choice is equal to any game menu options. if is equal it call a method that runs the game. 
			//If it is not equal it will output a invalid input and reprint the menu screen
			
			//TODO: Make it so it wipes all text out of the console when switching to a new game
			//Make it so it closes the console .
			
			if(choice.equals("guessing game") ||choice.equals("1") ||choice.equals("1. guessing game") || choice.equals("1.gussinggame")) {
				System.out.print("Guessing Game Running");
				guessingGame(input, difficulty);//Starts hiLow game. the reason for input is because it
				//brings the scanner object form Main method to the HiLow method.
			}else if (choice.equals("battle ship") ||choice.equals("2") ||choice.equals("2. battle ship")) {
				System.out.println("Battle Ship Is still under devlopment. please select a diffrent option");
				battleShip(input);
			}else if(choice.equals("exit") ||choice.equals("3") ||choice.equals("3. exit")) {
				System.out.println("Exiting Program");
				break;
			}else {
				System.out.println("Invalid Input. please try again\n");//this is what outputs when the user
				//enters a input that does not match anything above
			}	
		}
		input.close();//House cleaning
	}//Main 
	
	//This is the high low game. the Scanner Input means its asking for a
	//scanner object to be ran
	public static void guessingGame(Scanner input, String difficulty){ 
		System.out.println("Welcome to Hi Low!!!");
		int num;
		int Score = 0;
		int low;
		int high;
		Random randy = new Random();//Randy here is the random variable imported form the java.util libary
		while(true) {			//Sets up the game based on difficulty
		System.out.println("Please type the difficulty you want to play and press enter:\nDiffcultys:\nEasy\nNormal\nHard\nNick's Challanged\n"); //this prints all the dffcutly's in the game
		difficulty = input.nextLine().toLowerCase();//Player inputs what difficulty they want to play. 
		if (difficulty.equals("easy")) {
			num = randy.nextInt(1,11);//Randy Comes up with a number between 1 and 10
			System.out.println("Guess a number between 1 and 10?");//Outputs and lets the player know the range they need to guess in
			low = 1; //Sets lowest possible guess to 1
			high = 10; //Sets highest possible guess to 10
			break;
		}else if(difficulty.equals("normal")) {
			num = randy.nextInt(1,101);//Randy Comes up with a number between 1 and 100
			System.out.println("Guess a number between 1 and 100?");//Outputs and lets the player know the range they need to guess in
			low = 1;//Sets lowest possible guess to 1
			high = 100;//Sets highest possible guess to 100
			break;
		}else if(difficulty.equals("hard")){
			num = randy.nextInt(1,1001);//Randy Comes up with a number between 1 and 1000
			System.out.println("Guess a number between 1 and 1000?");//Outputs and lets the player know the range they need to guess in
			low = 1;//Sets lowest possible guess to 1
			high = 1000;//Sets highest possible guess to 1000
	    break; 
		}else if(difficulty.equals("nick's challanged") || difficulty.equals("nicks challanged")){//Blame Nick for this, It was not my idea.
			num = randy.nextInt(1,1_000_000_001); //Randy Comes up with a number between 1 and 1 billion
			System.out.println("Guess a number between 1 and 1,000,000,000?");//Outputs and lets the player know the range they need to guess in
			low = 1;//Sets lowest possible guess to 1
			high = 1_000_000_000;//Sets highest possible guess to 1 Billion
	    break;
	  }else {
			System.out.println("Invalid Input. please try again\n");
		}	
		}
		int guess;
		while(true) {
			guess = input.nextInt();
			if(guess >= low && guess <= high) {//this if makes sure that the guess is in range.
				//for example cant type 100 if the max number randy only can pick is 10
				Score++;//adds one to score. the lower score you have the better
				if(guess < num) {
					System.out.println("To low, guess a higher number!");
				}else if(guess > num){
					System.out.println("To high, guess a lower number!");
				}else if(guess == num) {
					input.nextLine();
					System.out.println("you win");//Lets the player know they won and prints there score
					System.out.println("It took you " + Score + " Guesses to get the right number!");
					System.out.println("Press enter key to go back to main menu");
					input.nextLine();
					break;//Breaks the while loop sending user back to main
				}
			}else if (guess < low){
			  //Lets the player know that there out of range and reminds them what 
				//the lowest number could be.
				System.out.println("Out of bounds please guess above " + low+ ".");
			}else if (guess > high){
				//Lets the player know that there out of range and reminds them what 
				//the highest number could be
				System.out.println("Out of bounds please guess below " + high+ ".");
			}
		}
		}
	
	
		public static void battleShip(Scanner input) {
			String Menu;//Sets Menu option string and outputs menu to player
			System.out.println("BATTLE SHIP");
			String ship = "$";
			String miss = "L";
			String hit = "*";
			String playerShips1[] = new String[5];//Sets playerships array size
			String playerShips2[] = new String[5];//Sets playerships array size
			String place = null; // varable used to place a ship
			String facing = null;
			String selector = null;
			String letter = null;
			String num = null;
			int cord;
			int shipCount = 5;
			playerShips1[0] = "carrier";//Sets playerships array value
			playerShips1[1] = "battleship";//Sets playerships array value
			playerShips1[2] = "destroyer";//Sets playerships array value
			playerShips1[3] = "submarine";//Sets playerships array value
			playerShips1[4] = "patrol boat";//Sets playerships array value
			playerShips2[0] = "carrier";//Sets playerships array value
			playerShips2[1] = "battleship";//Sets playerships array value
			playerShips2[2] = "destroyer";//Sets playerships array value
			playerShips2[3] = "submarine";//Sets playerships array value
			playerShips2[4] = "patrol boat";//Sets playerships array value
			while(true) {//Traps options in a loop so if an invalid option is made it wont continue to the game
				System.out.println("\n1. Start\n2. Rules\nPlease put the number or the name of the action you would like to perform and press enter.");
				Menu = input.nextLine().toLowerCase();
				if(Menu.equals("start") || Menu.equals("1")) {
					break;//Breaks and starts the game
				}else if(Menu.equals("rules") || Menu.equals("2")) {
					//Outputs the rules then tells the player to press enter to continue back to battleship menu
					System.out.println("		SETUP");
					System.out.println("Once you start the game before it prints player 1 sides it will say 'Player1 Press ENTER to placeships'\n"
							+ "Before player1 presses enter make sure that player 2 is not looking at the screen.");
					
					System.out.println("		TURNS");
				}else {
					System.out.println("Invalid Input. please try again\n");
				}
			}
			//this sets up both boards boardArray1 is player 1's and boardArray2 is player twos
			String boardArray1[] = new String[100];
			String boardArray2[] = new String[100];
			for(int i = 0; i < 100; i++) {//Sets all 100 values in array to display "-" the dash simulates empty tiles or "water"
				boardArray1[i] = "-";
				boardArray2[i] = "-";
			}
			
			
				System.out.println("Player1 Press ENTER to place ships");
				//This is so it waits for the player to ENTER so the nextline() stops waiting for the buffer.
				//it gives time for player1 to confirm that player 2 is not looking at the screen.
				input.nextLine();  
				
				while(true) {
					System.out.println(" 1 2 3 4 5 6 7 8 9 0"); 
					for(int x = 0; x < 10; x++) {//Sets Value of arrays
						if(x == 0) { 
							letter = "A";
						} else if(x == 1) {
							letter = "B";			
						}else if(x == 2) {
							letter = "C";
						}else if(x == 3) {
							letter = "D";
						}else if(x == 4) {
							letter = "E";
						}else if(x == 5) {
							letter = "F";
						}else if(x == 6) {
							letter = "G";
						}else if(x == 7) {
							letter = "H";
						}else if(x == 8) {
							letter = "I";
						}else if(x == 9) {
							letter = "J";}
						System.out.print(letter +" "); //Prints the table
						System.out.print(boardArray1[x]);//a
						System.out.print(" ");
						System.out.print(boardArray1[x+10]);//b
						System.out.print(" ");
						System.out.print(boardArray1[x+20]);//c
						System.out.print(" ");
						System.out.print(boardArray1[x+30]);//d
						System.out.print(" ");
						System.out.print(boardArray1[x+40]);//e
						System.out.print(" ");
						System.out.print(boardArray1[x+50]);//f
						System.out.print(" ");
						System.out.print(boardArray1[x+60]);//g
						System.out.print(" ");
						System.out.print(boardArray1[x+70]);//h
						System.out.print(" ");
						System.out.print(boardArray1[x+80]);//i
						System.out.print(" ");
						System.out.println(boardArray1[x+90]);//j
					}
						//Player places Ship
						System.out.println("Please Select a quardnet to put your ship at for example A2");
						selector = input.nextLine().toLowerCase();
						num = selector;//sets num equil to selector
						num = num.substring(1, 2);//remove the letter form the varable
						//this value will be used below when placeing ships. it will have value added to it to make it
						//equil the array number on the board
						cord = 0;
						
						// System.out.println("Num " + num); //this is for debugging to show value of num.
						// The if and else if below is to convert num varable
						// TODO: 
						//convert Type String to type int and add it to cord
						if(num.equals("2")){
							cord += 10;
						}else if(num.equals("3")) {
							cord += 20;
						}else if(num.equals("4")) {
							cord += 30;
						}else if(num.equals("5")) {
							cord += 40;
						}else if(num.equals("6")) {
							cord += 50;
						}else if(num.equals("7")) {
							cord += 60;
						}else if(num.equals("8")) {
							cord += 70;
						}else if(num.equals("9")) {
							cord += 80;
						}else if(num.equals("0")) {
							cord += 90;
						}else {
							System.out.println("Invalid input");
						}
						
						selector = selector.substring(0, 1);//removes the number from the variable 0 is start of index and 1 is end from were it starts and removes. 0 is the first String
						System.out.println("Selector " + selector); //converts the value to the 10's section
		
						if(selector.equals("b")) {
							cord += 1;
						}else if(selector.equals("c")) {
							cord += 2;
						}else if(selector.equals("d")) {
							cord += 3;
						}else if(selector.equals("e")) {
							cord += 4;
						}else if(selector.equals("f")) {
     				cord += 5;
						}else if(selector.equals("g")) {
							cord += 6;
						}else if(selector.equals("h")) {
							cord += 7;
						}else if(selector.equals("i")) {
							cord += 8;
						}else if(selector.equals("j")) {
							cord += 9;
						}
						
						
						if(boardArray1[cord].equals("-")) {
							
							System.out.print("What ship would you like to place? you can pick.\n");
								for(int y = 0; y < playerShips1.length; y++) {
									System.out.println(playerShips1[y]);
							}
						}
								
						place = input.nextLine().toLowerCase(); //Selecting the Ship that will be places
						
						if(place.equals(playerShips1[0])) {
									playerShips1[0] = "        ";
									while(true) {
									System.out.println("How would you like to place the ship?\n1. Upright\n2. Sideways");
									facing = input.nextLine().toLowerCase();//Placing ships, and making it so you cant place a ship out of bounds
										if(facing.equals("1")||facing.equals("upright") || facing.equals("1. upright")) //Place ship 1 upright
										{//placeing ship 1	
											if(cord-1 == 9 && cord >= 10||cord-1 == 19 && cord >= 20||cord-1 == 29 && cord >= 30||cord-1 == 39 && cord >= 											40||cord-1 == 49 && cord >= 50||cord-1 == 59 && cord >= 60||cord-1 == 69 && cord >= 70||cord-1 == 79 && cord >= 											80||cord-1 == 89 && cord >= 90) {
													boardArray1[cord+3] = ship;
													boardArray1[cord] = ship;
													boardArray1[cord+1] = ship;
													boardArray1[cord+2] = ship;
													shipCount = shipCount -1;
													break;
											}else if(cord+2 == 11 && cord <= 9||cord+2 == 21 && cord <= 19||cord+2 == 31 && cord <= 29||cord+2 == 41 && cord <= 39||cord+2 == 51 && cord <= 49||cord+2 == 61 && cord <= 69||cord+2 == 71 && cord <= 79||cord+2 == 81 && cord <= 89||cord+2 == 91 && cord <= 99) {
													boardArray1[cord-1] = ship;
													boardArray1[cord] = ship;
													boardArray1[cord-2] = ship;
													boardArray1[cord-3] = ship;	
													shipCount = shipCount -1;
													break;
											}else{
													boardArray1[cord-1] = ship;
													boardArray1[cord] = ship;
													boardArray1[cord+1] = ship;
													boardArray1[cord+2] = ship;
													shipCount = shipCount -1;
													break;
													
											}
										}else if(facing.equals("2")||facing.equals("sideways") || facing.equals("2. sideways"))//Place ship 2 sideways
										{
											if(cord-10 < 0) {
													boardArray1[cord+30] = ship;
													boardArray1[cord] = ship;
													boardArray1[cord+10] = ship;
													boardArray1[cord+20] = ship;
													shipCount = shipCount -1;
													break;
													
											}else if(cord+10 >= 100 || cord+20 < 99) {
													boardArray1[cord-10] = ship;
													boardArray1[cord] = ship;
													boardArray1[cord+20] = ship;
													boardArray1[cord+10] = ship;
													shipCount = shipCount -1;
													break;
													
											}else if(cord+20 > 99) {
													boardArray1[cord-10] = ship;
													boardArray1[cord] = ship;
													boardArray1[cord-20] = ship;
													boardArray1[cord-30] = ship;
													shipCount = shipCount -1;
													break;
													
											}else{
													boardArray1[cord-10] = ship;
													boardArray1[cord] = ship;
													boardArray1[cord+20] = ship;
													boardArray1[cord+10] = ship;
													shipCount = shipCount -1;
													break;
													
											}
											}else{
													System.out.println("Invalid position");
										
											}
										break;
										}
										}else if(place.equals(playerShips1[1])) {//placing ship 2
									playerShips1[1] = "       ";
									while(true) {
										System.out.println("How would you like to place the ship?\n1. Upright\n2. Sideways");
										facing = input.nextLine().toLowerCase();
										if(facing.equals("1")||facing.equals("upright") || facing.equals("1. upright")) //placing ship 2 upright
										{ 	
												if(cord-5 <= 9 && cord >= 10||cord-5 <= 19 && cord >= 20||cord-5 <= 29 && cord >= 30||cord-5 <= 39 && cord >= 												40||cord-5 <= 49 && cord >= 50||cord-5 <= 59 && cord >= 60||cord-5 <= 69 && cord >= 70||cord-5 <= 79 && cord 												>= 80||cord-5 <= 89 && cord >= 90) {
														boardArray1[cord] = ship;
														boardArray1[cord+1] = ship;
														boardArray1[cord+2] = ship;
														boardArray1[cord+3] = ship;
														boardArray1[cord+4] = ship;
														boardArray1[cord+5] = ship;
														shipCount = shipCount -1;
														break;
												}else if(cord+5 >= 11 && cord <= 9||cord+5 >= 21 && cord <= 19||cord+5 >= 31 && cord <= 29||cord+5 >= 41 && 													cord <= 39||cord+5 >= 51 && cord <= 49||cord+5 >= 61 && cord <= 69||cord+5 >= 71 && cord <= 79||cord+5 >= 													81 && cord <= 89||cord+5 >= 91 && cord <= 99) {
														boardArray1[cord-1] = ship;
														boardArray1[cord] = ship;
														boardArray1[cord-2] = ship;
														boardArray1[cord-3] = ship;
														boardArray1[cord-4] = ship;
														boardArray1[cord-5] = ship;
														shipCount = shipCount -1;
														break;
												}else{
													boardArray1[cord+5] = ship;
													boardArray1[cord+4] = ship;
													boardArray1[cord] = ship;
													boardArray1[cord+1] = ship;
													boardArray1[cord+2] = ship;
													boardArray1[cord+3] = ship;
													shipCount = shipCount -1;
													break;
												}
										}else if(facing.equals("2")||facing.equals("sideways") || facing.equals("2. sideways")){
											if(cord-30 < 0) {
												boardArray1[cord] = ship;
												boardArray1[cord+10] = ship;
												boardArray1[cord+20] = ship;
												boardArray1[cord+30] = ship;
												boardArray1[cord+40] = ship;
												boardArray1[cord+50] = ship;
												shipCount = shipCount -1;
												break;
											}else if(cord+10 > 99 || cord+20 < 99) {
												boardArray1[cord+10] = ship;
												boardArray1[cord] = ship;
												boardArray1[cord-10] = ship;
												boardArray1[cord-20] = ship;
												boardArray1[cord-30] = ship;
												boardArray1[cord-40] = ship;
												shipCount = shipCount -1;
												break;
											}else if(cord+20 > 99) {
												boardArray1[cord-10] = ship;
												boardArray1[cord] = ship;
												boardArray1[cord-20] = ship;
												boardArray1[cord-30] = ship;
												boardArray1[cord-40] = ship;
												boardArray1[cord-50] = ship;
												shipCount = shipCount -1;
												break;
											}else{
												boardArray1[cord-20] = ship;
												boardArray1[cord-10] = ship;
												boardArray1[cord] = ship;
												boardArray1[cord+20] = ship;
												boardArray1[cord+30] = ship;
												boardArray1[cord+40] = ship;
												shipCount = shipCount -1;
												break;
											}
										}else{
											System.out.println("Invalid position");
											
										}
										}
									}else if(place.equals(boardArray1[2])||place.equals("destroyer")) {
											playerShips1[2] = "       ";
											while(true) {
											System.out.println("How would you like to place the ship?\n1. Upright\n2. Sideways");
											facing = input.nextLine().toLowerCase();
											if(facing.equals("1")||facing.equals("upright") || facing.equals("1. upright")) //placing ship 3 upright
											{ 	
													if(cord-2 <= 9 && cord >= 10||cord-2 <= 19 && cord >= 20||cord-2 <= 29 && cord >= 30||cord-2 <= 39 && cord 													>= 40||cord-2 <= 49 && cord >= 50||cord-2 <= 59 && cord >= 60||cord-2 <= 69 && cord >= 70||cord-2 <= 79 && 													cord >= 80||cord-2 <= 89 && cord >= 90) {
															boardArray1[cord] = ship;
															boardArray1[cord+1] = ship;
															boardArray1[cord+2] = ship;
															shipCount = shipCount -1;
															break;
													}else if(cord+3 >= 11 && cord <= 9||cord+3 >= 21 && cord <= 19||cord+3 >= 31 && cord <= 29||cord+3 >= 41 && 													cord <= 39||cord+3 >= 51 && cord <= 49||cord+3 >= 61 && cord <= 69||cord+3 >= 71 && cord <= 79||cord+3 >= 													81 && cord <= 89||cord+3 >= 91 && cord <= 99) {
															boardArray1[cord-1] = ship;
															boardArray1[cord] = ship;
															boardArray1[cord-2] = ship;
															shipCount = shipCount -1;
															break;
													}else{
														boardArray1[cord-1] = ship;
														boardArray1[cord] = ship;
														boardArray1[cord+1] = ship;
														shipCount = shipCount -1;
														break;
													}
											}else if(facing.equals("2")||facing.equals("sideways") || facing.equals("2. sideways")){
												if(cord-30 < 0) {
													boardArray1[cord] = ship;
													boardArray1[cord+10] = ship;
													boardArray1[cord+20] = ship;
													shipCount = shipCount -1;
													break;
												}else if(cord+10 > 99 || cord+20 < 99) {
													boardArray1[cord+10] = ship;
													boardArray1[cord] = ship;
													boardArray1[cord-10] = ship;
													shipCount = shipCount -1;
													break;
												}else if(cord+20 > 99) {
													boardArray1[cord-10] = ship;
													boardArray1[cord] = ship;
													boardArray1[cord-20] = ship;
													shipCount = shipCount -1;
													break;
												}else{
													boardArray1[cord-10] = ship;
													boardArray1[cord] = ship;
													boardArray1[cord+10] = ship;
													shipCount = shipCount -1;
													break;
												}
											}
											}
										}else if(place.equals(playerShips1[3])){
											playerShips1[3] = "       ";
											while(true) {
											System.out.println("How would you like to place the ship?\n1. Upright\n2. Sideways");
											facing = input.nextLine().toLowerCase();
											if(facing.equals("1")||facing.equals("upright") || facing.equals("1. upright")) //placing ship 3 upright
											{ 	
													if(cord-2 <= 9 && cord >= 10||cord-2 <= 19 && cord >= 20||cord-2 <= 29 && cord >= 30||cord-2 <= 39 && cord 													>= 40||cord-2 <= 49 && cord >= 50||cord-2 <= 59 && cord >= 60||cord-2 <= 69 && cord >= 70||cord-2 <= 79 && 													cord >= 80||cord-2 <= 89 && cord >= 90) {
															boardArray1[cord] = ship;
															boardArray1[cord+1] = ship;
															boardArray1[cord+2] = ship;
															shipCount = shipCount -1;
															break;
													}else if(cord+3 >= 11 && cord <= 9||cord+3 >= 21 && cord <= 19||cord+3 >= 31 && cord <= 29||cord+3 >= 41 && 													cord <= 39||cord+3 >= 51 && cord <= 49||cord+3 >= 61 && cord <= 69||cord+3 >= 71 && cord <= 79||cord+3 >= 													81 && cord <= 89||cord+3 >= 91 && cord <= 99) {
															boardArray1[cord-1] = ship;
															boardArray1[cord] = ship;
															boardArray1[cord-2] = ship;
															shipCount = shipCount -1;
															break;
													}else{
														boardArray1[cord-1] = ship;
														boardArray1[cord] = ship;
														boardArray1[cord+1] = ship;
														shipCount = shipCount -1;
														break;
													}
											}else if(facing.equals("2")||facing.equals("sideways") || facing.equals("2. sideways")){
												if(cord-30 < 0) {
													boardArray1[cord] = ship;
													boardArray1[cord+10] = ship;
													boardArray1[cord+20] = ship;
													shipCount = shipCount -1;
													break;
												}else if(cord+10 > 99 || cord+20 < 99) {
													boardArray1[cord+10] = ship;
													boardArray1[cord] = ship;
													boardArray1[cord-10] = ship;
													shipCount = shipCount -1;
													break;
												}else if(cord+20 > 99) {
													boardArray1[cord-10] = ship;
													boardArray1[cord] = ship;
													boardArray1[cord-20] = ship;
													shipCount = shipCount -1;
													break;
												}else{
													boardArray1[cord-10] = ship;
													boardArray1[cord] = ship;
													boardArray1[cord+10] = ship;
													shipCount = shipCount -1;
													break;
												}
											}
											}
											
										}else if (place.equals(playerShips1[4])){
											playerShips1[4] = "            ";
											while(true) {
												System.out.println("How would you like to place the ship?\n1. Upright\n2. Sideways");
												facing = input.nextLine().toLowerCase();
												if(facing.equals("1")||facing.equals("upright") || facing.equals("1. upright")) //placing ship 3 upright
												{ 	
														if(cord-2 <= 9 && cord >= 10||cord-2 <= 19 && cord >= 20||cord-2 <= 29 && cord >= 30||cord-2 <= 39 && cord 													>= 40||cord-2 <= 49 && cord >= 50||cord-2 <= 59 && cord >= 60||cord-2 <= 69 && cord >= 70||cord-2 <= 79 && 													cord >= 80||cord-2 <= 89 && cord >= 90) {
																boardArray1[cord] = ship;
																boardArray1[cord+1] = ship;
																shipCount = shipCount -1;
																break;
														}else if(cord+3 >= 11 && cord <= 9||cord+3 >= 21 && cord <= 19||cord+3 >= 31 && cord <= 29||cord+3 >= 41 && 													cord <= 39||cord+3 >= 51 && cord <= 49||cord+3 >= 61 && cord <= 69||cord+3 >= 71 && cord <= 79||cord+3 >= 													81 && cord <= 89||cord+3 >= 91 && cord <= 99) {
																boardArray1[cord-1] = ship;
																boardArray1[cord] = ship;
																shipCount = shipCount -1;
																break;
														}else{
															boardArray1[cord] = ship;
															boardArray1[cord+1] = ship;
															shipCount = shipCount -1;
															break;
														}
												}else if(facing.equals("2")||facing.equals("sideways") || facing.equals("2. sideways")){
													if(cord-30 < 0) {
														boardArray1[cord] = ship;
														boardArray1[cord+10] = ship;
														shipCount = shipCount -1;
														break;
													}else if(cord+10 > 99 || cord+20 < 99) {
														boardArray1[cord] = ship;
														boardArray1[cord-10] = ship;
														shipCount = shipCount -1;
														break;
													}else if(cord+10 > 99) {
														boardArray1[cord-10] = ship;
														boardArray1[cord] = ship;
														shipCount = shipCount -1;
														break;
													}else{
														boardArray1[cord] = ship;
														boardArray1[cord+10] = ship;
														shipCount = shipCount -1;
														break;
													}
												}
												}
											}else if(place.equals(playerShips1[3])){
												playerShips1[3] = "       ";
												while(true) {
												System.out.println("How would you like to place the ship?\n1. Upright\n2. Sideways");
												facing = input.nextLine().toLowerCase();
												if(facing.equals("1")||facing.equals("upright") || facing.equals("1. upright")) //placing ship 3 upright
												{ 	
														if(cord-2 <= 9 && cord >= 10||cord-2 <= 19 && cord >= 20||cord-2 <= 29 && cord >= 30||cord-2 <= 39 && cord 													>= 40||cord-2 <= 49 && cord >= 50||cord-2 <= 59 && cord >= 60||cord-2 <= 69 && cord >= 70||cord-2 <= 79 && 													cord >= 80||cord-2 <= 89 && cord >= 90) {
																boardArray1[cord] = ship;
																boardArray1[cord+1] = ship;
																boardArray1[cord+2] = ship;
																shipCount = shipCount -1;
																break;
														}else if(cord+3 >= 11 && cord <= 9||cord+3 >= 21 && cord <= 19||cord+3 >= 31 && cord <= 29||cord+3 >= 41 && 													cord <= 39||cord+3 >= 51 && cord <= 49||cord+3 >= 61 && cord <= 69||cord+3 >= 71 && cord <= 79||cord+3 >= 													81 && cord <= 89||cord+3 >= 91 && cord <= 99) {
																boardArray1[cord-1] = ship;
																boardArray1[cord] = ship;
																boardArray1[cord-2] = ship;
																shipCount = shipCount -1;
																break;
														}else{
															boardArray1[cord-1] = ship;
															boardArray1[cord] = ship;
															boardArray1[cord+1] = ship;
															shipCount = shipCount -1;
															break;
														}
												}else if(facing.equals("2")||facing.equals("sideways") || facing.equals("2. sideways")){
													if(cord-30 < 0) {
														boardArray1[cord] = ship;
														boardArray1[cord+10] = ship;
														boardArray1[cord+20] = ship;
														shipCount = shipCount -1;
														break;
													}else if(cord+10 > 99 || cord+20 < 99) {
														boardArray1[cord+10] = ship;
														boardArray1[cord] = ship;
														boardArray1[cord-10] = ship;
														shipCount = shipCount -1;
														break;
													}else if(cord+20 > 99) {
														boardArray1[cord-10] = ship;
														boardArray1[cord] = ship;
														boardArray1[cord-20] = ship;
														shipCount = shipCount -1;
														break;
													}else{
														boardArray1[cord-10] = ship;
														boardArray1[cord] = ship;
														boardArray1[cord+10] = ship;
														shipCount = shipCount -1;
														break;
													}
												}
												}
											
											
										}else {
									System.out.println("Invalid placement");
								}
						
						if(shipCount == 0) {// This is tempary if its still in code when showing you remove this
							//TODO:
							//Clear all text on screen to clear ship placements
							System.out.println("\n\\n\\n\\n\\n\\n\\n\\n\\n\\n\\n\\n\\n\\n\\n\\n\\n\\n\\n\\n\\n\\n\\n\\n\\n\\n\\n\\n\\n\\n\\n\\n\\n\\n\\n\\n\\n\\n\\n\\n\\n\\n\\n\\n\\n\\n\\n\\n\\n\\n\\n\\n\\n\\n\\n\\n\\n\\n\\n");
							
						}
						break;//Breaks the place test loop so you can place the next ship
					}
				/*This code is for debugging purposes I use it as an array cheat sheet
					for(int y = 0; y < 10; y++) {//Sets Value of arrays
						System.out.print(y);//a
						System.out.print(" ");
						System.out.print(y+10);//b
						System.out.print(" ");
						System.out.print(y+20);//b
						System.out.print(" ");
						System.out.print(y+30);//b
						System.out.print(" ");
						System.out.print(y+40);//b
						System.out.print(" ");
						System.out.print(y+50);//b
						System.out.print(" ");
						System.out.print(y+60);//b
						System.out.print(" ");
						System.out.print(y+70);//b
						System.out.print(" ");
						System.out.print(y+80);//b
						System.out.print(" ");
						System.out.println(y+90);//b
					}*/ 
				
				//TODO:
				//Make player 2 placing ships
				System.out.println("Player2 Press ENTER to place ships");
				//This is so it waits for the player to ENTER so the nextline() stops waiting for the buffer.
				//it gives time for player1 to confirm that player 2 is not looking at the screen.
				input.nextLine();  
				while(true) {
					
				}
				
				
			}
}//end class
